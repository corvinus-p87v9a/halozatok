﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Zenesz
    {
        public byte ZeneszId { get; set; }
        public string Name { get; set; }
    }
}
