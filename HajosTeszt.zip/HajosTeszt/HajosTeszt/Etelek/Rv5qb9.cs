﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Rv5qb9
    {
        public int Id { get; set; }
        public string Movie { get; set; }
    }
}
