﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Lkx2mo
    {
        public int Id { get; set; }
        public string Nev { get; set; }
        public byte Eletkor { get; set; }
        public string Klub { get; set; }
    }
}
