﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class T509zq
    {
        public int Sk { get; set; }
        public string Nev { get; set; }
    }
}
