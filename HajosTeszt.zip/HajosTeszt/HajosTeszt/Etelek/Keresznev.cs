﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Keresznev
    {
        public int NevId { get; set; }
        public string Keresztnev { get; set; }
    }
}
