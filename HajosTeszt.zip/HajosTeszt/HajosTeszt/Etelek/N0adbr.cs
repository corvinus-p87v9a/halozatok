﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class N0adbr
    {
        public int KajaSk { get; set; }
        public string Nev { get; set; }
        public string Kaja { get; set; }
    }
}
