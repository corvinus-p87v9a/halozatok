﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class A5n4oj
    {
        public byte KonyvId { get; set; }
        public string Konyvnev { get; set; }
    }
}
