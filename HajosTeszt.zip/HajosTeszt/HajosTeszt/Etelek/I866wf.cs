﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class I866wf
    {
        public string Név { get; set; }
        public string Telefonszám { get; set; }
        public int Id { get; set; }
    }
}
