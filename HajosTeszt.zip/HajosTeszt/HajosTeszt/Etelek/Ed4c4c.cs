﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Ed4c4c
    {
        public int NevSk { get; set; }
        public string Nev { get; set; }
        public string Csillagjegy { get; set; }
    }
}
