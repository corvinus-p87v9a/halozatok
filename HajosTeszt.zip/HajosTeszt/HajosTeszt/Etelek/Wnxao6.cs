﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Wnxao6
    {
        public byte SkTarot { get; set; }
        public string Tarotszoveg { get; set; }
    }
}
