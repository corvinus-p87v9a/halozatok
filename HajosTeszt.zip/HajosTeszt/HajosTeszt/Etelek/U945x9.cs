﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class U945x9
    {
        public int NévSk { get; set; }
        public string Név { get; set; }
        public string Ital { get; set; }
    }
}
