﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class CsergoDaniel
    {
        public int Id { get; set; }
        public string Név { get; set; }
    }
}
