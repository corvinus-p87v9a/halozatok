﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class A29z1n
    {
        public byte EtteremId { get; set; }
        public string EtteremNev { get; set; }
    }
}
