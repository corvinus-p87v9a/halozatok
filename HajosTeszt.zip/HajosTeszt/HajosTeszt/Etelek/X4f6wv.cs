﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class X4f6wv
    {
        public byte JatekosId { get; set; }
        public string JatekosNev { get; set; }
    }
}
