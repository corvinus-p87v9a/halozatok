﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Xsegpl
    {
        public int VizipipadohanyId { get; set; }
        public string VizipipaDohanyNeve { get; set; }
    }
}
