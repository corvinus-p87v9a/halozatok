﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Gkkojw
    {
        public int MemeId { get; set; }
        public string MemeText { get; set; }
    }
}
