﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Btbl7l
    {
        public byte Id { get; set; }
        public string Film { get; set; }
    }
}
