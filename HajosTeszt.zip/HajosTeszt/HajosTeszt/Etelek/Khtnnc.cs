﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Khtnnc
    {
        public int Id { get; set; }
        public string Nev { get; set; }
        public double Magassag { get; set; }
        public string Sportag { get; set; }
    }
}
