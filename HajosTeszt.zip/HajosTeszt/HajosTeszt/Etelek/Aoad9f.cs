﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Aoad9f
    {
        public int DinoId { get; set; }
        public string Dinonev { get; set; }
    }
}
