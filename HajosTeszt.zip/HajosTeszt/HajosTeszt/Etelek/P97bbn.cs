﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class P97bbn
    {
        public int TelefonSk { get; set; }
        public string Típus { get; set; }
        public int? Ár { get; set; }
        public string AvsI { get; set; }
    }
}
