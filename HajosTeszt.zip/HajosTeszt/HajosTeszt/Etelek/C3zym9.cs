﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class C3zym9
    {
        public byte Id { get; set; }
        public string Text { get; set; }
    }
}
