﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Zgtpmn
    {
        public string Lofajta { get; set; }
        public int LoId { get; set; }
    }
}
