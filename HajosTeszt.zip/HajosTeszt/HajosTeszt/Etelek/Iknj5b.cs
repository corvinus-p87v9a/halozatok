﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Iknj5b
    {
        public int TortenetSk { get; set; }
        public string TortenetSzoveg { get; set; }
        public string TortenetSzemely { get; set; }
    }
}
