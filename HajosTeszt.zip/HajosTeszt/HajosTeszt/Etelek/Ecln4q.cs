﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Ecln4q
    {
        public byte SorozatokId { get; set; }
        public string Sorozatoknev { get; set; }
    }
}
