﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class P87v9a
    {
        public int Id { get; set; }
        public string Étel { get; set; }
        public string Hozzávaló { get; set; }
    }
}
