﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Ewhn1v
    {
        public int ÜgyfélSk { get; set; }
        public string Név { get; set; }
        public string Cím { get; set; }
        public int? SzületésiÉv { get; set; }
    }
}
