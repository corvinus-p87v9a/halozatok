﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class D1zo8l
    {
        public byte ParkoloTipusId { get; set; }
        public string ParkoloTipus { get; set; }
    }
}
