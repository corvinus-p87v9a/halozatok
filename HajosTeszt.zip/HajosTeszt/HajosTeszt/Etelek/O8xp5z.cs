﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class O8xp5z
    {
        public byte Filmid { get; set; }
        public string Filmcim { get; set; }
    }
}
