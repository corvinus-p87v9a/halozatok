﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class D8apkd
    {
        public byte SzalonId { get; set; }
        public string SzalonNev { get; set; }
    }
}
