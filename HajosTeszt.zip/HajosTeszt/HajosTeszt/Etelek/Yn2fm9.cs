﻿using System;
using System.Collections.Generic;

#nullable disable

namespace HajosTeszt.Etelek
{
    public partial class Yn2fm9
    {
        public int SongId { get; set; }
        public string SongTitle { get; set; }
        public string SongOwner { get; set; }
    }
}
